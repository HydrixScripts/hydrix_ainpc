local QBX = exports['qb-core']:GetCoreObject()

local spawnedNPCs = {}
local currentNPCPed = nil
local interacting = false
local conversationActive = false
local nearNPCIndex = nil  -- Used for voice

-- ====================== MODEL LOADING ======================
local function LoadModel(model)
    local hash = GetHashKey(model)
    if not IsModelValid(hash) then return false end

    RequestModel(hash)
    local timeout = 0
    while not HasModelLoaded(hash) and timeout < 5000 do
        Wait(10)
        timeout += 10
    end
    return HasModelLoaded(hash), hash
end

-- ====================== SPAWN NPC ======================
local function SpawnNPC(index)
    local npcData = Config.NPCs[index]
    if not npcData then return end

    local loaded, hash = LoadModel(npcData.model)
    if not loaded then
        print('^1[hydrix_ainpc]^7 Failed to load model: ' .. npcData.model)
        return
    end

    local ped = CreatePed(4, hash, npcData.coords.x, npcData.coords.y, npcData.coords.z, npcData.heading, false, true)

    SetEntityAsMissionEntity(ped, true, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    FreezeEntityPosition(ped, true)
    SetPedCanRagdoll(ped, false)
    SetModelAsNoLongerNeeded(hash)

    spawnedNPCs[index] = { ped = ped, type = npcData.type }

    exports.ox_target:addLocalEntity(ped, {
        {
            name = 'hydrix_ainpc_talk_' .. index,
            icon = 'fas fa-comments',
            label = 'Talk to NPC',
            distance = Config.InteractionDistance,
            onSelect = function()
                StartInteraction(index)
            end
        }
    })
end

-- ====================== CLEANUP ======================
local function CleanupNPC(index)
    local data = spawnedNPCs[index]
    if data and data.ped and DoesEntityExist(data.ped) then
        exports.ox_target:removeLocalEntity(data.ped)
        DeleteEntity(data.ped)
    end
    spawnedNPCs[index] = nil
end

-- ====================== STREAMING ======================
Citizen.CreateThread(function()
    while true do
        local playerCoords = GetEntityCoords(PlayerPedId())

        for i, npc in ipairs(Config.NPCs) do
            local dist = #(playerCoords - npc.coords)
            if dist < Config.StreamDistance then
                if not spawnedNPCs[i] then
                    SpawnNPC(i)
                end
            else
                if spawnedNPCs[i] then
                    CleanupNPC(i)
                end
            end
        end
        Wait(2000)
    end
end)

-- ====================== NEAR NPC DETECTION (for Voice) ======================
Citizen.CreateThread(function()
    while true do
        local playerCoords = GetEntityCoords(PlayerPedId())
        nearNPCIndex = nil

        for i, data in pairs(spawnedNPCs) do
            local dist = #(playerCoords - Config.NPCs[i].coords)
            if dist < Config.InteractionDistance + 2.0 then
                nearNPCIndex = i
                break
            end
        end
        Wait(500)
    end
end)

-- ====================== NPC LOOK AT PLAYER ======================
Citizen.CreateThread(function()
    while true do
        if interacting and currentNPCPed and DoesEntityExist(currentNPCPed) then
            local playerCoords = GetEntityCoords(PlayerPedId())
            TaskTurnPedToFaceCoord(currentNPCPed, playerCoords.x, playerCoords.y, playerCoords.z, 500)
        end
        Wait(500)
    end
end)

-- ====================== SPEECH BUBBLE ======================
local function ShowNPCBubble(text)
    if not currentNPCPed or not DoesEntityExist(currentNPCPed) then return end
    local coords = GetEntityCoords(currentNPCPed)
    AddTextEntry('HYDRIX_NPC', text)
    SetFloatingHelpTextWorldPosition(1, coords.x, coords.y, coords.z + 1.3)
    SetFloatingHelpTextStyle(1, 1, 2, -1, 3, 0)
    BeginTextCommandDisplayHelp('HYDRIX_NPC')
    EndTextCommandDisplayHelp(2, false, false, -1)
end

-- ====================== START TEXT INTERACTION ======================
function StartInteraction(index)
    if interacting then return end

    interacting = true
    conversationActive = true
    currentNPCPed = spawnedNPCs[index] and spawnedNPCs[index].ped

    SendNUIMessage({
        action = 'openChat',
        npcName = Config.NPCs[index].type
    })

    SetNuiFocus(true, true)
end

-- ====================== NUI CALLBACKS ======================
RegisterNUICallback('sendMessage', function(data, cb)
    if not conversationActive then return cb('ok') end
    TriggerServerEvent('hydrix_ainpc:server:sendMessage', data.message)
    cb('ok')
end)

RegisterNUICallback('closeChat', function(_, cb)
    SetNuiFocus(false, false)
    interacting = false
    conversationActive = false
    SendNUIMessage({ action = 'closeChat' })
    cb('ok')
end)

-- ====================== RECEIVE RESPONSE ======================
RegisterNetEvent('hydrix_ainpc:client:receiveResponse', function(responseText, emotion)
    if not interacting then return end

    SendNUIMessage({
        action = 'receiveMessage',
        sender = 'npc',
        message = responseText
    })

    ShowNPCBubble(responseText)
    TriggerEmotion(emotion)
end)

-- ====================== EMOTIONS ======================
function TriggerEmotion(emotion)
    if not currentNPCPed or not DoesEntityExist(currentNPCPed) then return end

    local scenarios = {
        fear = 'WORLD_HUMAN_STAND_IMPATIENT',
        angry = 'WORLD_HUMAN_GUARD_STAND',
        happy = 'WORLD_HUMAN_HAMMERING',
        neutral = 'WORLD_HUMAN_CLIPBOARD'
    }
    TaskStartScenarioInPlace(currentNPCPed, scenarios[emotion] or scenarios.neutral, 0, true)
end

-- ====================== VOICE COMMAND (PMA-VOICE) ======================
RegisterCommand('npctalkvoice', function()
    if not nearNPCIndex or interacting or not Config.VoiceEnabled then 
        QBX.Functions.Notify('No NPC nearby or already in conversation', 'error')
        return 
    end

    -- Just notify for now (real STT coming later)
    QBX.Functions.Notify('🎤 Voice mode is not fully implemented yet', 'info', 4000)
    QBX.Functions.Notify('Use peek to open text chat', 'primary', 5000)

    -- Optional: Auto open text chat after delay (remove if you don't want this)
    -- Citizen.SetTimeout(800, function()
    --     StartInteraction(nearNPCIndex)
    -- end)
end, false)

RegisterKeyMapping('npctalkvoice', 'Speak to nearby NPC (Voice)', 'keyboard', Config.VoiceKey)

-- ====================== RESOURCE STOP ======================
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for i in pairs(spawnedNPCs) do
        CleanupNPC(i)
    end
    SetNuiFocus(false, false)
end)