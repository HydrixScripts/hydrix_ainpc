window.addEventListener('load', function() {
    const chatContainer = document.getElementById('chat-container');
    const closeBtn = document.getElementById('close-btn');
    const sendBtn = document.getElementById('send-btn');
    const messageInput = document.getElementById('message-input');
    const chatMessages = document.getElementById('chat-messages');
    const npcName = document.getElementById('npc-name');

    let isOpen = false;

    // Listen for messages from Lua
    window.addEventListener('message', function(event) {
        const data = event.data;

        if (data.action === 'openChat') {
            npcName.innerText = data.npcName ? data.npcName.toUpperCase() : 'NPC';
            chatContainer.style.display = 'flex';
            chatMessages.innerHTML = '';
            isOpen = true;
            messageInput.focus();
        } 
        else if (data.action === 'closeChat') {
            chatContainer.style.display = 'none';
            isOpen = false;
        } 
        else if (data.action === 'receiveMessage') {
            const msgDiv = document.createElement('div');
            msgDiv.classList.add('message', data.sender);
            msgDiv.innerText = data.message;
            chatMessages.appendChild(msgDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    });

    // Send message
    function sendMessage() {
        const text = messageInput.value.trim();
        if (text === '' || !isOpen) return;

        const msgDiv = document.createElement('div');
        msgDiv.classList.add('message', 'user');
        msgDiv.innerText = text;
        chatMessages.appendChild(msgDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        fetch(`https://${GetParentResourceName()}/sendMessage`, {
            method: 'POST',
            body: JSON.stringify({ message: text }),
            headers: { 'Content-Type': 'application/json' }
        });

        messageInput.value = '';
    }

    // Close chat
    function closeChat() {
        fetch(`https://${GetParentResourceName()}/closeChat`, {
            method: 'POST',
            body: JSON.stringify({}),
            headers: { 'Content-Type': 'application/json' }
        }).catch(err => console.error("Close error:", err));

        chatContainer.style.display = 'none';
        isOpen = false;
    }

    // Event Listeners
    sendBtn.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') sendMessage();
    });

    closeBtn.addEventListener('click', closeChat);

    document.addEventListener('keyup', function(e) {
        if (e.key === 'Escape' && isOpen) {
            closeChat();
        }
    });
});