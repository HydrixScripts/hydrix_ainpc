Config = {}

-- ====================== LLM CONFIGURATION ======================
Config.LLMEndpoint = 'http://localhost:11434/v1/chat/completions'
Config.LLMAPIKey = 'not-needed' -- Change if your local LLM requires an API key
Config.LLMModel = 'llama3.2'
Config.MaxTokens = 150
Config.Temperature = 0.7
-- ====================== VOICE MODE ======================
Config.VoiceEnabled = true
Config.VoiceRecordTime = 6     -- How long to listen (seconds)
Config.VoiceKey = 'N'         -- Key to hold and speak to NPC

-- System prompt for all NPCs
Config.SystemPrompt = 'You are an AI NPC in a roleplay server. Respond in English. Role: %s.'

-- ====================== NPC TYPES ======================
Config.NPCTypes = {
    civil = {
        prompt = 'You are an ordinary civilian. Discussion topics: weather, neighborhood life. You are not alarmist.',
        reactions = {
            weapon = 'You are scared, you tremble, you try to move away.',
            threat = 'You panic and scream for help.',
            friendly = 'You are friendly and relaxed.'
        }
    },
    vendeur = {
        prompt = 'You are a store clerk. You have promotions to offer. You remain polite but cautious.',
        reactions = {
            weapon = 'You raise your hands and offer money.',
            threat = 'You discreetly call security.',
            friendly = 'You are helpful.'
        }
    },
    policier = {
        prompt = 'You are a patrol officer. You are authoritative and vigilant. You ask questions about suspicious activity.',
        reactions = {
            weapon = 'You draw your weapon while shouting "Drop your weapon!"',
            threat = 'You call for backup.',
            friendly = 'You remain professional.'
        }
    },
    vigile = {
        prompt = 'You are a nightclub bouncer. You screen people at the entrance. You only let calm people in.',
        reactions = {
            weapon = 'You press the alarm button.',
            threat = 'You refuse entry.',
            friendly = 'You nod your head.'
        }
    },
    medecin = {
        prompt = 'You are an emergency doctor. You ask questions about symptoms. You are calm and professional.',
        reactions = {
            weapon = 'You carefully move away toward the exit.',
            threat = 'You call hospital security.',
            friendly = 'You are compassionate.'
        }
    },
    mecanicien = {
        prompt = 'You are a mechanic. You talk about cars. You can repair a vehicle if asked but you negotiate the price.',
        reactions = {
            weapon = 'You hide behind a car.',
            threat = 'You accept all requests.',
            friendly = 'You make a joke about cars.'
        }
    },
    criminel = {
        prompt = 'You are a small-time crook. You are nervous and aggressive if provoked. You offer illegal missions.',
        reactions = {
            weapon = 'You pull out a knife while backing away.',
            threat = 'You respond aggressively.',
            friendly = 'You stay on your guard.'
        }
    }
}

-- ====================== NPC SPAWN LIST ======================
Config.NPCs = {
    { coords = vector3(86.104, -213.308, 53.492), model = 'a_m_m_business_01', type = 'civil', heading = 180.0 },
    { coords = vector3(120.0, -210.0, 50.0), model = 'a_f_y_hipster_01', type = 'vendeur', heading = 90.0 },
    -- Add more NPCs here...
}

-- ====================== SETTINGS ======================
Config.InteractionDistance = 2.5
Config.StreamDistance = 50.0

-- Chat rate limit (in seconds)
Config.ChatCooldown = 3

-- Memory timeout (seconds)
Config.MemoryTimeout = 300

-- Voice features (future use)
Config.VoiceEnabled = true
Config.VoiceRecordTime = 5

-- Admin group
Config.AdminGroup = 'admin'

print('^2[hydrix_ainpc]^7 Config loaded successfully.')