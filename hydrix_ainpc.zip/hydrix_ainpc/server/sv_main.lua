local QBX = exports['qb-core']:GetCoreObject()

local cooldowns = {}
local npcMemory = {}

RegisterNetEvent('hydrix_ainpc:server:sendMessage', function(message)
    local src = source
    local Player = QBX.Functions.GetPlayer(src)
    if not Player then return end

    if cooldowns[src] and os.time() - cooldowns[src] < Config.ChatCooldown then
        TriggerClientEvent('hydrix_ainpc:client:receiveResponse', src, "I'm listening, please wait a moment...", 'neutral')
        return
    end
    cooldowns[src] = os.time()

    if not npcMemory[src] then npcMemory[src] = {} end
    if not npcMemory[src][1] then
        npcMemory[src][1] = { conversation = {} }
        local systemMsg = Config.SystemPrompt:format("npc") .. '\n' .. Config.NPCTypes.civil.prompt
        table.insert(npcMemory[src][1].conversation, { role = 'system', content = systemMsg })
    end

    table.insert(npcMemory[src][1].conversation, { role = 'user', content = message })

    PerformHttpRequest(Config.LLMEndpoint, function(err, text)
        local reply = "Sorry, I'm having trouble responding right now."

        if err == 200 then
            local data = json.decode(text)
            if data?.choices?[1]?.message?.content then
                reply = data.choices[1].message.content
            end
        else
            print('^1[hydrix_ainpc]^7 LLM Error: ' .. tostring(err))
        end

        table.insert(npcMemory[src][1].conversation, { role = 'assistant', content = reply })

        local lower = reply:lower()
        local emotion = 'neutral'
        if lower:find('fear') or lower:find('scared') then emotion = 'fear'
        elseif lower:find('angry') or lower:find('mad') then emotion = 'angry'
        elseif lower:find('happy') or lower:find('smile') then emotion = 'happy' end

        TriggerClientEvent('hydrix_ainpc:client:receiveResponse', src, reply, emotion)

    end, 'POST', json.encode({
        model = Config.LLMModel,
        messages = npcMemory[src][1].conversation,
        max_tokens = Config.MaxTokens,
        temperature = Config.Temperature
    }), { ['Content-Type'] = 'application/json' })
end)

AddEventHandler('playerDropped', function()
    local src = source
    npcMemory[src] = nil
    cooldowns[src] = nil
end)

QBX.Commands.Add('ainpc', 'AI NPC Management', {}, false, function(source, args)
    if args[1] and args[1]:lower() == 'forget' then
        npcMemory[source] = nil
        TriggerClientEvent('ox_lib:notify', source, {title = 'Hydrix AI NPC', description = 'Conversation memory cleared', type = 'success'})
    else
        TriggerClientEvent('ox_lib:notify', source, {title = 'Hydrix AI NPC', description = 'Usage: /ainpc forget', type = 'info'})
    end
end, 'admin')