fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Hydrix_Scripts'
description 'Advanced AI NPC System with Local LLM - QBox + ox_target + ox_lib'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',  -- ox_lib
    'config.lua'
}

client_scripts {
    'client/cl_main.lua'
}

server_scripts {
    'server/sv_main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/script.js',
    'html/style.css'
}

dependencies {
    'qbx_core',
    'ox_lib',
    'ox_target'
}